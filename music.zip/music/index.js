const El_Music = require("./lib/DiscordMusicBot");
const client = new El_Music();
const fs = require('fs'),
	path = require('path');
fs.readdirSync(path.resolve(__dirname, './deploy')).forEach(files => {
	var file = require('./deploy/' + files);
});

module.exports = client;
